Chronored
====

LudumDare entry, theme was "10 seconds"

